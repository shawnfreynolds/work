from django.db import models

#create models here
class ET_paloalto_permitted_ip(models.Model):
   # id = models.IntegerField(primary_key=True)
    text = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    # Define other columns as needed

    class Meta:
        db_table = 'paloalto_permitted_ip'  # Specify the actual table name
        managed = False  # Tell Django not to manage this table

    def __str__(self):
        return self.text
		
class ET_paloalto_permitted_url(models.Model):
   # id = models.IntegerField(primary_key=True)
    text = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    # Define other columns as needed

    class Meta:
        db_table = 'paloalto_permitted_url'  # Specify the actual table name
        managed = False  # Tell Django not to manage this table

    def __str__(self):
        return self.text
		
class ET_paloalto_denied_ip(models.Model):
   # id = models.IntegerField(primary_key=True)
    text = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    # Define other columns as needed

    class Meta:
        db_table = 'paloalto_denied_ip'  # Specify the actual table name
        managed = False  # Tell Django not to manage this table

    def __str__(self):
        return self.text
		
class ET_paloalto_denied_url(models.Model):
   # id = models.IntegerField(primary_key=True)
    text = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    # Define other columns as needed

    class Meta:
        db_table = 'paloalto_denied_url'  # Specify the actual table name
        managed = False  # Tell Django not to manage this table

    def __str__(self):
        return self.text
