from django.shortcuts import render
import re
from django.conf import settings  # Import settings
from django.http import HttpResponse
#from .models import ET_paloalto_permitted_ip, ET_paloalto_permitted_url, ET_paloalto_denied_ip, ET_paloalto_denied_url
# Create your views here.

def home(request):
    # stuff = LDAPBackend().get_all_permissions(user)
#    USER = request.user.ldap_user._user
#    return render(request, "home.html", {'USER':USER})
    return render(request, "paloalto/home.html")

def sites(request):
    return render(request, "paloalto/sites/deniedsites.html")

