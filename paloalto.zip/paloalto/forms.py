from django import forms

class StringInputForm(forms.Form):
    input_text = forms.CharField(label='Enter Text', max_length=255)    

class IPAddressForm(forms.Form):
    text = forms.CharField(label='Enter Text', max_length=255)
    address = forms.GenericIPAddressField(protocol='IPv4', label="IPv4 Address")
