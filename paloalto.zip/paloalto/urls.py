# build/urls.py
from . import views
from findip.forms import LoginForm
from django.contrib.auth import views as auth_views
from django.urls import path

urlpatterns = [
    path('sites', views.sites),
    path('', views.home, name='home'),
    path('add_input', views.string_input_view, name='string_input'),
#    path('add_permitted_url', views.url_add_input),
    path('add_permitted_ip',views.ip_add_input),
#    path('Permitted_URL', views.permitted_ip_url_view, name='permitted_url_database_view'),
    path('Permitted_IP',views.permitted_ip_database_view, name='permitted_ip_database_view'),
    path('success1', views.success_view, name='success1'),
]
