from django.shortcuts import render, redirect
import re
from django.conf import settings  # Import settings
from django.http import HttpResponse
#from .models import ET_paloalto_permitted_ip, ET_paloalto_permitted_url, ET_paloalto_denied_ip, ET_paloalto_denied_url
#from .forms import StringInputForm
from .models import *
from .forms import *

# Create your views here.

def home(request):
    # stuff = LDAPBackend().get_all_permissions(user)
#    USER = request.user.ldap_user._user
#    return render(request, "home.html", {'USER':USER})
    return render(request, "paloalto/home.html")

def sites(request):
    return render(request, "paloalto/sites/deniedsites.html")

def string_input_view(request):
    if request.method == 'POST':
        form = StringInputForm(request.POST)
        if form.is_valid():
            input_string = form.cleaned_data['input_text']
            url =  input_string + "/"
            star_url = "*." + input_string + "/"
            ET_paloalto_permitted_url.objects.create(text=url)
            ET_paloalto_permitted_url.objects.create(text=star_url)
            return redirect('success1')  # Redirect to a success page
    else:
        form = StringInputForm()
    return render(request, 'paloalto/string_input.html', {'form': form})

def success_view(request):
    column2_values = ET_paloalto_permitted_url.objects.values_list('text', flat=True)
    context = {'column2_values': column2_values}
    return render(request, 'paloalto/success1.html', context)

def url_add_input(request):
    if request.method == 'POST':
        form = StringInputForm(request.POST)
        if form.is_valid():
            input_string = form.cleaned_data['input_text']
            url =  input_string + "/"
            star_url = "*." + input_string + "/"
            ET_paloalto_permitted_url.objects.create(text=url)
            ET_paloalto_permitted_url.objects.create(text=star_url)
            return redirect('success1')  # Redirect to a success page
    else:
        form = StringInputForm()
    return render(request, 'paloalto/string_input.html', {'form': form})

def ip_add_input(request):
    if request.method == 'POST':
        form = StringInputForm(request.POST)
        if form.is_valid():
            input_string = form.cleaned_data['input_text']
            ip =  input_string
            ET_paloalto_permitted_ip.objects.create(text=ip)
            return redirect('permitted_ip_database_view')  # Redirect to a success page
    else:
        form = StringInputForm()
    return render(request, 'paloalto/string_input.html', {'form': form})

def permitted_url_database_view(request):
    column2_values = ET_paloalto_permitted_url.objects.values_list('text', flat=True)
    context = {'column2_values': column2_values}
    return render(request, 'paloalto/success1.html', context)

def permitted_ip_database_view(request):
    column2_values = ET_paloalto_permitted_ip.objects.values_list('text', flat=True)
    context = {'column2_values': column2_values}
    return render(request, 'paloalto/success1.html', context)

def denied_url_database_view(request):
    column2_values = ET_paloalto_denied_url.objects.values_list('text', flat=True)
    context = {'column2_values': column2_values}
    return render(request, 'paloalto/success1.html', context)

def denied_ip_database_view(request):
    column2_values = ET_paloalto_denied_ip.objects.values_list('text', flat=True)
    context = {'column2_values': column2_values}
    return render(request, 'paloalto/success1.html', context)

