/* ================================================================
   Config Grep — app.js
   Files are tracked as "dirkey/filename" so the backend knows
   which directory each file belongs to.
   ================================================================ */

'use strict';

const BASE = window.location.pathname.replace(/\/+$/, '');
const apiUrl = path => BASE + path;

/* ── STATE ──────────────────────────────────────────────────── */
let dirData      = {};   // { access: {path, files:[...]}, config: {...} }
let allKeys      = [];   // flat list of "dirkey/filename"
let selectedKeys = new Set();
let queryCounter = 0;
let lastInput    = null;

/* ── INIT ───────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  addQuery();
  loadFiles();
  // After layout settles, fix the body-wrap height
  requestAnimationFrame(fixHeight);
  window.addEventListener('resize', fixHeight);
});

function fixHeight() {
  const header = document.querySelector('header');
  const stats  = document.querySelector('.stats-bar');
  if (!header || !stats) return;
  const used = header.offsetHeight + stats.offsetHeight;
  document.querySelector('.body-wrap').style.height = `calc(100vh - ${used}px)`;
}

/* ── FILE LOADING ───────────────────────────────────────────── */
async function loadFiles() {
  setStatus('Loading files…');
  try {
    const res  = await fetch(apiUrl('/api/files/'));
    const data = await res.json();

    dirData  = data.dirs  || {};
    allKeys  = [];

    for (const [key, info] of Object.entries(dirData)) {
      for (const f of info.files) {
        allKeys.push(`${key}/${f}`);
      }
    }

    selectedKeys = new Set(allKeys);
    renderFileList();

    const total = allKeys.length;
    document.getElementById('totalCount').textContent    = total;
    document.getElementById('selectedCount').textContent = total;

    // Show per-dir counts in stats bar
    const parts = Object.entries(dirData).map(([k, v]) =>
      `${k}: <span class="num">${v.files.length}</span>`
    );
    document.getElementById('dirStats').innerHTML = parts.join(' &nbsp;|&nbsp; ');

    // Report any load errors
    const errs = Object.entries(data.errors || {});
    if (errs.length) {
      setStatus(errs.map(([k, e]) => `${k}: ${e}`).join(' | '), true);
    } else {
      setStatus('');
    }
  } catch (e) {
    setStatus(`Load error: ${e.message}`, true);
    document.getElementById('fileList').innerHTML =
      `<div class="list-msg list-err">${esc(e.message)}</div>`;
  }
}

/* ── SIDEBAR RENDERING ──────────────────────────────────────── */
function renderFileList(filter = '') {
  const el = document.getElementById('fileList');
  el.innerHTML = '';

  for (const [dirKey, info] of Object.entries(dirData)) {
    const filtered = info.files.filter(f =>
      f.toLowerCase().includes(filter.toLowerCase())
    );

    const head = document.createElement('div');
    head.className = 'dir-group-head';
    head.innerHTML = `<span>${dirKey}</span><span class="dir-path">${esc(info.path)}</span>`;
    el.appendChild(head);

    if (!filtered.length) {
      const msg = document.createElement('div');
      msg.className = 'list-msg';
      msg.textContent = 'No files match filter.';
      el.appendChild(msg);
      continue;
    }

    for (const f of filtered) {
      const key = `${dirKey}/${f}`;
      const item = document.createElement('div');
      item.className = `file-item ${selectedKeys.has(key) ? 'selected' : ''}`;
      item.onclick = () => toggleFile(key);
      item.title = `${info.path}/${f}`;
      item.innerHTML =
        `<div class="file-check">${selectedKeys.has(key) ? '&#10003;' : ''}</div>` +
        `<div class="file-name">${esc(f)}</div>`;
      el.appendChild(item);
    }
  }

  updateSelectedCount();
}

function filterFiles() {
  renderFileList(document.getElementById('fileFilter').value);
}

function toggleFile(key) {
  if (selectedKeys.has(key)) selectedKeys.delete(key);
  else selectedKeys.add(key);
  renderFileList(document.getElementById('fileFilter').value);
}

function selectAll() {
  selectedKeys = new Set(allKeys);
  renderFileList(document.getElementById('fileFilter').value);
}

function selectNone() {
  selectedKeys = new Set();
  renderFileList(document.getElementById('fileFilter').value);
}

function updateSelectedCount() {
  document.getElementById('selectedCount').textContent = selectedKeys.size;
}

/* ── QUERY ROWS ─────────────────────────────────────────────── */
function addQuery(value = '') {
  queryCounter++;
  const id  = `q${queryCounter}`;
  const row = document.createElement('div');
  row.className = 'query-row';
  row.id = `row_${id}`;
  row.innerHTML =
    `<span class="query-num">${document.querySelectorAll('.query-row').length + 1}</span>` +
    `<span class="query-prefix">$</span>` +
    `<input class="query-input" id="${id}"` +
    ` placeholder='-i "pattern"  |  -v "shutdown"  |  -A4 "interface"'` +
    ` autocomplete="off" spellcheck="false" value="${esc(value)}">` +
    `<button class="btn-remove" onclick="removeQuery('${id}')" title="Remove">×</button>`;

  document.getElementById('queriesContainer').appendChild(row);

  const input = document.getElementById(id);
  input.addEventListener('keydown', handleQueryKey);
  input.addEventListener('focus',   () => { lastInput = input; });
  input.focus();
  reNumber();
  fixHeight();
}

function removeQuery(id) {
  const row = document.getElementById(`row_${id}`);
  if (row) row.remove();
  if (!document.querySelectorAll('.query-row').length) addQuery();
  reNumber();
  fixHeight();
}

function reNumber() {
  document.querySelectorAll('.query-num').forEach((el, i) => {
    el.textContent = i + 1;
  });
}

function handleQueryKey(e) {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); runSearch(); }
  else if (e.key === 'Enter' && !e.shiftKey)          { e.preventDefault(); addQuery(); }
}

function insertExample(el) {
  const val = el.textContent.trim();
  const target = lastInput || document.querySelector('.query-input:last-of-type');
  if (target) { target.value = val; target.focus(); }
}

/* ── SEARCH ─────────────────────────────────────────────────── */
async function runSearch() {
  const inputs  = document.querySelectorAll('.query-input');
  const queries = Array.from(inputs).map(i => i.value.trim()).filter(Boolean);
  if (!queries.length) return;

  const btn = document.getElementById('runBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>';

  const empty = document.getElementById('emptyState');
  if (empty) empty.remove();

  const ra = document.getElementById('resultsArea');
  const loader = document.createElement('div');
  loader.className = 'loading-row';
  loader.innerHTML = `<span class="spinner"></span><span>Searching ${selectedKeys.size} file${selectedKeys.size !== 1 ? 's' : ''}…</span>`;
  ra.appendChild(loader);

  const payload = {
    queries,
    files: selectedKeys.size === allKeys.length ? [] : Array.from(selectedKeys),
  };

  try {
    const res  = await fetch(apiUrl('/api/search/'), {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'X-CSRFToken':   getCookie('csrftoken'),
      },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    loader.remove();

    if (data.error) {
      appendError(ra, data.error);
    } else {
      data.results.forEach(r => appendResult(ra, r));
    }

    ra.scrollTop = ra.scrollHeight;
  } catch (e) {
    loader.remove();
    appendError(ra, e.message);
  }

  btn.disabled = false;
  btn.innerHTML = '&#9654; Run Search';
}

function clearResults() {
  document.getElementById('resultsArea').innerHTML =
    '<div class="empty-state" id="emptyState">' +
    '<div class="empty-icon">&#9906;</div>' +
    '<div class="empty-text">Enter a query above and click Run Search</div>' +
    '</div>';
}

/* ── RESULT RENDERING ───────────────────────────────────────── */
function appendResult(container, r) {
  const hasOutput = r.output && r.output.trim().length > 0;
  const isError   = r.error || r.returncode === 2;
  const noMatch   = !isError && !hasOutput;
  const lines     = hasOutput ? r.output.trim().split('\n') : [];

  let blockCls, tag, tagCls;
  if (isError)   { blockCls = 'has-error'; tag = 'Error';    tagCls = 'tag-error';    }
  else if (noMatch) { blockCls = 'no-match'; tag = 'No Match'; tagCls = 'tag-no-match'; }
  else           { blockCls = 'has-match'; tag = 'Match';    tagCls = 'tag-match';    }

  const outId = `out_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
  const block = document.createElement('div');
  block.className = `result-block ${blockCls}`;

  block.innerHTML =
    `<div class="result-header">` +
      `<span class="result-tag ${tagCls}">${tag}</span>` +
      `<span class="result-query">grep ${esc(r.query)}</span>` +
      `<div class="result-meta">` +
        (hasOutput ? `<span class="result-count">${lines.length} line${lines.length !== 1 ? 's' : ''}</span>` : '') +
        (hasOutput ? `<button class="btn-copy" onclick="copyOut('${outId}')">copy</button>` : '') +
      `</div>` +
    `</div>` +
    `<div class="result-output">` +
      (hasOutput
        ? `<pre id="${outId}">${colorize(r.output)}</pre>`
        : `<span class="hl-no-match">No matches found.</span>`) +
    `</div>`;

  container.appendChild(block);
}

function appendError(container, msg) {
  const block = document.createElement('div');
  block.className = 'result-block has-error';
  block.innerHTML =
    `<div class="result-header">` +
      `<span class="result-tag tag-error">Error</span>` +
      `<span class="result-query">${esc(msg)}</span>` +
    `</div>`;
  container.appendChild(block);
}

/* ── COLORIZER ──────────────────────────────────────────────── */
function colorize(raw) {
  return raw.split('\n').map(line => {
    if (!line) return '';
    // Match: filename:rest  or  filename-rest  (only when filename has . or /)
    const m = line.match(/^([^:\n\r]+?)([:–\-])(\d+)([:–\-])(.*)$/) ||
              line.match(/^([^:\n\r]+?)([:–])(.*)$/);
    if (m && (m[1].includes('/') || m[1].includes('.'))) {
      if (m.length === 6) {
        const sc = m[2] === ':' ? 'hl-sep-match' : 'hl-sep-ctx';
        return `<span class="hl-filename">${esc(m[1])}</span>` +
               `<span class="${sc}">${esc(m[2])}</span>` +
               `<span style="color:var(--text-dim)">${esc(m[3])}</span>` +
               `<span class="${sc}">${esc(m[4])}</span>` +
               esc(m[5]);
      } else {
        const sc = m[2] === ':' ? 'hl-sep-match' : 'hl-sep-ctx';
        return `<span class="hl-filename">${esc(m[1])}</span>` +
               `<span class="${sc}">${esc(m[2])}</span>` +
               esc(m[3]);
      }
    }
    return esc(line);
  }).join('\n');
}

/* ── HELPERS ────────────────────────────────────────────────── */
function esc(s) {
  return String(s || '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function setStatus(msg, isErr = false) {
  const el = document.getElementById('statusMsg');
  el.textContent = msg;
  el.style.color = isErr ? 'var(--open-text)' : 'var(--accent2)';
}

function getCookie(name) {
  const v = document.cookie.match('(^|;)\\s*' + name + '=([^;]*)');
  return v ? v[2] : '';
}

async function copyOut(id) {
  const pre = document.getElementById(id);
  if (!pre) return;
  try { await navigator.clipboard.writeText(pre.innerText); }
  catch {
    const ta = document.createElement('textarea');
    ta.value = pre.innerText;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
}
