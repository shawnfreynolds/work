# Config Grep — Django App

Searches `/cisco/access` and `/cisco/config` (or any configured directories) via a web UI
that matches the ANS subnet_breakdown color scheme.

## Directory Structure

Drop the `configgrep/` folder into your Django project root:

```
/ans/webapps/djangoans/answeb/
├── answeb/
│   ├── settings.py   ← edit
│   └── urls.py       ← edit
└── configgrep/       ← drop here
    ├── __init__.py
    ├── apps.py
    ├── views.py
    ├── urls.py
    ├── templates/configgrep/index.html
    └── static/configgrep/
        ├── css/style.css
        └── js/app.js
```

---

## Step 1 — settings.py

```python
INSTALLED_APPS = [
    ...
    'configgrep',
]

# Optional overrides (these are the defaults):
CONFIG_GREP_DIRS = {
    'access': '/cisco/access',
    'config': '/cisco/config',
}
CONFIG_GREP_TIMEOUT = 15   # seconds per grep call
```

---

## Step 2 — urls.py

```python
from django.urls import path, include

urlpatterns = [
    ...
    path('configgrep/', include('configgrep.urls', namespace='configgrep')),
]
```

App will be live at:  http://your-server/configgrep/

---

## Step 3 — Static files

```bash
cd /ans/webapps/djangoans/answeb
python manage.py collectstatic --noinput
```

---

## Step 4 — Restart

```bash
systemctl restart djangoans    # or touch wsgi.py, etc.
```

---

## Permissions

The Django process user needs read access to both directories:

```bash
# ACL method (preferred on RHEL/CentOS)
setfacl -R -m u:django:rX /cisco/access
setfacl -R -m u:django:rX /cisco/config

# Or simple world-read
chmod -R o+rX /cisco/access /cisco/config
```

---

## Adding More Directories

Just add to `CONFIG_GREP_DIRS` in settings.py — no code changes needed:

```python
CONFIG_GREP_DIRS = {
    'access':  '/cisco/access',
    'config':  '/cisco/config',
    'routers': '/cisco/routers',
}
```

---

## Grep Examples

| Input                        | Description                              |
|------------------------------|------------------------------------------|
| `interface GigabitEthernet`  | Basic keyword search                     |
| `-i "router ospf"`           | Case-insensitive                         |
| `-v "shutdown"`              | Invert — lines NOT matching              |
| `-A4 "interface"`            | 4 lines after match                      |
| `-B2 "ip address"`           | 2 lines before match                     |
| `-C3 "snmp"`                 | 3 lines context (before+after)           |
| `-n "ntp server"`            | Show line numbers                        |
| `-E "^interface (Gi\|Fa)"`  | Extended regex                           |
| `-l "bgp"`                   | List only filenames that match           |
| `-in "aaa"`                  | Combined: case-insensitive + line nums   |

The `grep` keyword prefix is optional — `-i "ospf"` and `grep -i "ospf"` both work.
