from django.urls import path
from . import views

app_name = 'configgrep'

urlpatterns = [
    path('',              views.index,      name='index'),
    path('api/files/',    views.list_files, name='list_files'),
    path('api/search/',   views.search,     name='search'),
]
