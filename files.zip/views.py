import os
import shlex
import subprocess
import json

from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST
from django.shortcuts import render

# Config directories — override in Django settings as CONFIG_GREP_DIRS dict
CONFIG_DIRS = getattr(settings, 'CONFIG_GREP_DIRS', {
    'access': '/cisco/access',
    'config': '/cisco/config',
})

GREP_TIMEOUT = getattr(settings, 'CONFIG_GREP_TIMEOUT', 15)


def index(request):
    return render(request, 'configgrep/index.html')


@require_GET
def list_files(request):
    """Return files grouped by directory key."""
    result = {}
    errors = {}
    for key, path in CONFIG_DIRS.items():
        try:
            files = sorted(
                f for f in os.listdir(path)
                if os.path.isfile(os.path.join(path, f))
            )
            result[key] = {'path': path, 'files': files}
        except FileNotFoundError:
            errors[key] = f'Directory not found: {path}'
        except PermissionError:
            errors[key] = f'Permission denied: {path}'
        except Exception as e:
            errors[key] = str(e)
    return JsonResponse({'dirs': result, 'errors': errors})


@csrf_exempt
@require_POST
def search(request):
    """
    POST JSON:
        queries  - list of grep arg strings, e.g. ['-i "ospf"', '-v shutdown']
        files    - list of "dirkey/filename"; empty = all files in all dirs
    """
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON body'}, status=400)

    queries  = data.get('queries', [])
    selected = data.get('files', [])

    if not queries:
        return JsonResponse({'error': 'No queries provided'}, status=400)

    # Build absolute file path list
    file_paths = []
    if selected:
        for entry in selected:
            parts = entry.split('/', 1)
            if len(parts) != 2:
                continue
            dir_key, fname = parts
            fname = os.path.basename(fname)   # prevent path traversal
            base  = CONFIG_DIRS.get(dir_key)
            if not base:
                continue
            full = os.path.join(base, fname)
            if os.path.isfile(full):
                file_paths.append(full)
    else:
        for key, path in CONFIG_DIRS.items():
            try:
                for f in sorted(os.listdir(path)):
                    full = os.path.join(path, f)
                    if os.path.isfile(full):
                        file_paths.append(full)
            except Exception:
                pass

    if not file_paths:
        return JsonResponse({'error': 'No matching config files found'}, status=404)

    results = []
    for raw_query in queries:
        raw_query = raw_query.strip()
        if not raw_query:
            continue

        # Strip leading "grep" keyword if user typed it
        stripped = raw_query
        if stripped.lower().startswith('grep '):
            stripped = stripped[5:].strip()

        try:
            args = shlex.split(stripped)
        except ValueError as e:
            results.append({'query': raw_query, 'output': f'Parse error: {e}',
                            'returncode': -1, 'error': True})
            continue

        cmd = ['grep'] + args + file_paths
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=GREP_TIMEOUT)
            output = proc.stdout
            if proc.returncode == 2 and proc.stderr:
                output = proc.stderr
            results.append({'query': raw_query, 'output': output,
                            'returncode': proc.returncode, 'error': False})
        except subprocess.TimeoutExpired:
            results.append({'query': raw_query,
                            'output': f'Timeout: query exceeded {GREP_TIMEOUT}s',
                            'returncode': -1, 'error': True})
        except FileNotFoundError:
            results.append({'query': raw_query, 'output': 'grep not found on this system',
                            'returncode': -1, 'error': True})
        except Exception as e:
            results.append({'query': raw_query, 'output': str(e),
                            'returncode': -1, 'error': True})

    return JsonResponse({'results': results})
