# Config Grep — Django App

## Installation (3 steps)

### 1. Copy the app directory

```bash
cp -r configgrep/ /ans/webapps/djangoans/answeb/
```

### 2. Edit settings.py

```python
INSTALLED_APPS = [
    ...
    'configgrep',
]

# Optional — these are the defaults:
CONFIG_GREP_DIRS = {
    'access': '/cisco/access',
    'config': '/cisco/config',
}
CONFIG_GREP_TIMEOUT = 15  # seconds
```

### 3. Edit urls.py

```python
from django.urls import path, include

urlpatterns = [
    ...
    path('configgrep/', include('configgrep.urls', namespace='configgrep')),
]
```

No `collectstatic` needed — all CSS and JS is embedded directly in the template.

Restart Django, then open:  http://your-server/configgrep/

---

## Permissions

```bash
# Grant the Django process user read access to both config dirs
setfacl -R -m u:django:rX /cisco/access /cisco/config
```

---

## Adding More Directories

```python
CONFIG_GREP_DIRS = {
    'access':  '/cisco/access',
    'config':  '/cisco/config',
    'routers': '/cisco/routers',   # just add a line
}
```

---

## Grep Examples

| Input | Description |
|-------|-------------|
| `interface GigabitEthernet` | Basic search |
| `-i "router ospf"` | Case-insensitive |
| `-v "shutdown"` | Lines NOT matching |
| `-A4 "interface"` | 4 lines after match |
| `-B2 "ip address"` | 2 lines before match |
| `-C3 "snmp"` | Context (before+after) |
| `-n "ntp server"` | Show line numbers |
| `-E "^interface (Gi\|Fa)"` | Extended regex |
| `-l "bgp"` | List matching filenames only |
| `-in "aaa"` | Case-insensitive + line numbers |

The `grep` keyword prefix is optional.
Ctrl+Enter runs the search from any input. Enter adds a new query row.
