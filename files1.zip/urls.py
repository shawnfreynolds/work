from django.urls import path
from . import views

app_name = 'configgrep'

urlpatterns = [
    path('',              views.index,      name='index'),
    path('api/files/',    views.list_files, name='list_files'),
    path('api/file/',     views.view_file,  name='view_file'),
    path('api/search/',   views.search,     name='search'),
]
